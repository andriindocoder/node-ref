const url =
  "mongodb://replacewithyourown:lo$#h$g6J8kd@ds111455.mlab.com:11455/craigslistcars";

module.exports = url;
